import java.sql.*;

public class MySQLDemo {

    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/table name?useSSL=false&serverTimezone=UTC";


    // 数据库的用户名与密码
    static final String USER = "root";
    static final String PASS = "mysql database password";

    public static void main(String[] args) {
        Connection conn = null;
        Statement stmt = null;
        try{
            // register JDBC driver
            Class.forName(JDBC_DRIVER);

            // open the link
            System.out.println("Connect database...");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);

            // select from database
            stmt = conn.createStatement();
            String sql;
            sql = "SELECT id, name, url FROM websites";
            ResultSet rs = stmt.executeQuery(sql);

            // show data in database
            while(rs.next()){
                // search
                int id  = rs.getInt("id");
                String name = rs.getString("name");
                String url = rs.getString("url");

                // output data
                System.out.print("ID: " + id);
                System.out.print(", hostname: " + name);
                System.out.print(", host URL: " + url);
                System.out.print("\n");
            }
            // close
            rs.close();
            stmt.close();
            conn.close();
        }catch(SQLException se){
            // deal with JDBC error
            se.printStackTrace();
        }catch(Exception e){
            // deal with Class.forName error
            e.printStackTrace();
        }finally{
            // close resource
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("Goodbye!");
    }
}